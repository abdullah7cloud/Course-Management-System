<?php
session_start();
include_once "../includes/auth.php";
include_once "../includes/db_connect.php";
include_once "../includes/security.php";
require_login();

try {
    // Use prepared statement for security
    $stmt = $pdo->prepare("
        SELECT s.*, u.Username 
        FROM staff s 
        JOIN user u ON s.UserID = u.UserID 
        WHERE s.IsActive = 1
        ORDER BY s.Department, s.FirstName
    ");
    $stmt->execute();
    $staff = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Staff list error: " . $e->getMessage());
    $staff = [];
    $error = "Unable to load staff information. Please try again later.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Staff Management - Course Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', sans-serif;
        }
        .staff-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            border: none;
        }
        .department-badge {
            font-size: 0.8rem;
        }
        .salary-amount {
            font-family: 'Courier New', monospace;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-graduation-cap"></i> Course Management
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="../index.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <span class="navbar-text me-3">
                    <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['username']); ?>
                </span>
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2><i class="fas fa-chalkboard-teacher me-2"></i>Staff Directory</h2>
                <p class="text-muted mb-0">Manage faculty members and staff information</p>
            </div>
            <div class="text-end">
                <span class="badge bg-primary fs-6 mb-2 d-block"><?php echo count($staff); ?> Active Staff</span>
                <a href="../index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Error:</strong> <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (empty($staff)): ?>
            <div class="alert alert-info text-center py-5">
                <i class="fas fa-users fa-3x mb-3"></i>
                <h4>No Staff Members Found</h4>
                <p class="mb-3">There are no active staff members in the system.</p>
                <small class="text-muted">Staff members can be added through the database management tools.</small>
            </div>
        <?php else: ?>
            <!-- Staff Statistics -->
            <div class="row mb-4">
                <?php
                $departments = array_count_values(array_column($staff, 'Department'));
                $totalSalary = array_sum(array_column($staff, 'Salary'));
                $avgSalary = count($staff) > 0 ? $totalSalary / count($staff) : 0;
                ?>
                <div class="col-md-3">
                    <div class="card bg-primary text-white text-center">
                        <div class="card-body py-3">
                            <h6 class="card-title">Total Departments</h6>
                            <h4><?php echo count($departments); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white text-center">
                        <div class="card-body py-3">
                            <h6 class="card-title">Average Salary</h6>
                            <h4>$<?php echo number_format($avgSalary, 0); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-info text-white text-center">
                        <div class="card-body py-3">
                            <h6 class="card-title">Total Salary</h6>
                            <h4>$<?php echo number_format($totalSalary, 0); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-white text-center">
                        <div class="card-body py-3">
                            <h6 class="card-title">Staff Count</h6>
                            <h4><?php echo count($staff); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card staff-card">
                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-list me-2"></i>Staff Members
                    </h5>
                    <div>
                        <small>Sorted by Department & Name</small>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Staff Name</th>
                                    <th>Email</th>
                                    <th>Department</th>
                                    <th>Salary</th>
                                    <th>Hire Date</th>
                                    <th>Username</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($staff as $member): ?>
                                <tr>
                                    <td><strong>#<?php echo (int)$member['StaffID']; ?></strong></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($member['FirstName'] . ' ' . $member['LastName']); ?></strong>
                                        <?php if (!empty($member['Email'])): ?>
                                            <br>
                                            <small class="text-muted">
                                                <i class="fas fa-envelope me-1"></i>
                                                <a href="mailto:<?php echo htmlspecialchars($member['Email']); ?>" class="text-decoration-none">
                                                    <?php echo htmlspecialchars($member['Email']); ?>
                                                </a>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($member['Email'])): ?>
                                            <a href="mailto:<?php echo htmlspecialchars($member['Email']); ?>">
                                                <?php echo htmlspecialchars($member['Email']); ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">Not provided</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge department-badge bg-info">
                                            <i class="fas fa-building me-1"></i>
                                            <?php echo htmlspecialchars($member['Department']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="salary-amount text-success">
                                            $<?php echo number_format($member['Salary'], 2); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                        $hireDate = new DateTime($member['HireDate']);
                                        echo $hireDate->format('M j, Y');
                                        ?>
                                        <br>
                                        <small class="text-muted">
                                            (<?php echo $hireDate->diff(new DateTime())->format('%y years'); ?>)
                                        </small>
                                    </td>
                                    <td>
                                        <code><?php echo htmlspecialchars($member['Username']); ?></code>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" 
                                                    onclick="viewStaff(<?php echo $member['StaffID']; ?>)"
                                                    title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-outline-info" 
                                                    onclick="contactStaff('<?php echo htmlspecialchars($member['Email']); ?>')"
                                                    title="Send Email"
                                                    <?php echo empty($member['Email']) ? 'disabled' : ''; ?>>
                                                <i class="fas fa-envelope"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Department Breakdown -->
            <div class="card mt-4">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Department Breakdown</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php foreach ($departments as $dept => $count): ?>
                        <div class="col-md-3 mb-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="fw-semibold"><?php echo htmlspecialchars($dept); ?></span>
                                <span class="badge bg-primary"><?php echo $count; ?> staff</span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function viewStaff(staffId) {
            alert(`Viewing staff member #${staffId}\n\nThis would show detailed staff information including contact details and assigned courses.`);
        }

        function contactStaff(email) {
            if (email) {
                window.location.href = `mailto:${email}`;
            } else {
                alert('No email address available for this staff member.');
            }
        }

        // Department filter functionality
        function filterByDepartment(dept) {
            alert(`Filtering staff by department: ${dept}\n\nThis would filter the staff list to show only members from the selected department.`);
        }
    </script>
</body>
</html>