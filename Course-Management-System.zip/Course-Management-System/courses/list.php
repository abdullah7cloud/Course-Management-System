<?php
/**
 * Course List Page - Course Management System
 * 
 * This page displays all courses in the system with search, filter, and management capabilities.
 * Only accessible to logged-in users.
 */

// Start session to access user authentication data
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION['logged_in'])) {
    header("Location: ../login.php");
    exit; // Stop script execution after redirect
}

// Include database connection and course model for data operations
include_once "../includes/db_connect.php";
include_once "../includes/course_model.php";

// Initialize variables
$courses = [];          // Array to store course data
$search_term = '';      // Variable for search input
$filter_status = 'all'; // Default filter status

// Check if the page is accessed via GET method (form submission or filter)
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Get search term from URL parameters, default to empty string if not set
    $search_term = $_GET['search'] ?? '';
    // Get filter status from URL parameters, default to 'all' if not set
    $filter_status = $_GET['status'] ?? 'all';
    
    // If search term is provided, search courses by the term
    if (!empty($search_term)) {
        $courses = searchCourses($search_term);
    } else {
        // No search term, apply filter based on status
        if ($filter_status === 'active') {
            // Get all active courses using model function
            $courses = getAllCourses();
        } elseif ($filter_status === 'inactive') {
            // Get inactive courses with direct database query
            global $pdo; // Access global database connection
            try {
                // Query to get inactive courses with instructor information
                $query = "SELECT c.*, s.FirstName, s.LastName FROM course c LEFT JOIN staff s ON c.StaffID = s.StaffID WHERE c.IsActive = 0 ORDER BY c.CourseName";
                $stmt = $pdo->prepare($query);
                $stmt->execute();
                $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) {
                // Log database error and set courses to empty array
                error_log("Error getting inactive courses: " . $e->getMessage());
                $courses = [];
            }
        } else {
            // Get all courses (both active and inactive)
            global $pdo; // Access global database connection
            try {
                // Query to get all courses with instructor information
                $query = "SELECT c.*, s.FirstName, s.LastName FROM course c LEFT JOIN staff s ON c.StaffID = s.StaffID ORDER BY c.CourseName";
                $stmt = $pdo->prepare($query);
                $stmt->execute();
                $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) {
                // Log database error and set courses to empty array
                error_log("Error getting all courses: " . $e->getMessage());
                $courses = [];
            }
        }
    }
} else {
    // If not a GET request (e.g., direct page access), get all courses
    $courses = getAllCourses();
}

// Check for session messages (success/error messages from previous operations)
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];           // Message text
    $message_type = $_SESSION['message_type']; // Message type (success, danger, etc.)
    
    // Clear session messages after retrieving to prevent re-display
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Course List - Course Management System</title>
    <!-- External CSS libraries -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Custom CSS styles */
        
        /* Base body styling */
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', sans-serif;
        }
        
        /* Navbar styling */
        .navbar-brand {
            font-weight: 600;
        }
        
        /* Table header styling */
        .table th {
            background: #2c3e50;
            color: white;
        }
        
        /* Search box styling */
        .search-box {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        /* Status badge styling */
        .status-badge {
            font-size: 0.8em;
        }
        
        /* Action buttons container */
        .action-buttons {
            display: flex;
            flex-direction: column;
            gap: 8px;
            min-width: 140px;
        }
        
        /* Base button styling */
        .action-buttons .btn {
            padding: 8px 12px;
            font-size: 13px;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
            border: none;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }
        
        /* Button hover effect */
        .action-buttons .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        /* View button specific styling */
        .btn-view {
            background: linear-gradient(135deg, #17a2b8, #138496);
            color: white;
            border: 1px solid #138496;
        }
        
        .btn-view:hover {
            background: linear-gradient(135deg, #138496, #117a8b);
            color: white;
        }
        
        /* Edit button specific styling */
        .btn-edit {
            background: linear-gradient(135deg, #ffc107, #e0a800);
            color: #000;
            border: 1px solid #e0a800;
        }
        
        .btn-edit:hover {
            background: linear-gradient(135deg, #e0a800, #d39e00);
            color: #000;
        }
        
        /* Activate button specific styling */
        .btn-activate {
            background: linear-gradient(135deg, #28a745, #218838);
            color: white;
            border: 1px solid #218838;
        }
        
        .btn-activate:hover {
            background: linear-gradient(135deg, #218838, #1e7e34);
            color: white;
        }
        
        /* Deactivate button specific styling */
        .btn-deactivate {
            background: linear-gradient(135deg, #6c757d, #5a6268);
            color: white;
            border: 1px solid #5a6268;
        }
        
        .btn-deactivate:hover {
            background: linear-gradient(135deg, #5a6268, #545b62);
            color: white;
        }
        
        /* Delete button specific styling */
        .btn-delete {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
            border: 1px solid #c82333;
        }
        
        .btn-delete:hover {
            background: linear-gradient(135deg, #c82333, #bd2130);
            color: white;
        }
        
        /* Table responsive design */
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
        }
        
        /* Table row hover effect */
        .table-hover tbody tr:hover {
            background-color: rgba(0, 123, 255, 0.05);
        }
        
        /* Mobile responsive styles */
        @media (max-width: 768px) {
            /* Stack action buttons horizontally on mobile */
            .action-buttons {
                flex-direction: row;
                flex-wrap: wrap;
                gap: 5px;
            }
            
            /* Adjust button size for mobile */
            .action-buttons .btn {
                flex: 1;
                min-width: 70px;
                font-size: 12px;
                padding: 6px 8px;
            }
            
            /* Hide button text, show only icons on mobile */
            .action-buttons .btn span.text {
                display: none;
            }
            
            .action-buttons .btn i {
                margin-right: 0 !important;
            }
        }
        
        /* Card styling */
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        /* Card header with gradient */
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <!-- Brand/Logo -->
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-graduation-cap me-2"></i>Course Management System
            </a>
            
            <!-- Navigation Links -->
            <div class="navbar-nav ms-auto">
                <!-- Dashboard Link -->
                <a class="nav-link" href="../dashboard.php">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                
                <!-- Add Course Link -->
                <a class="nav-link" href="create.php">
                    <i class="fas fa-plus me-1"></i>Add Course
                </a>
                
                <!-- Display logged-in username -->
                <span class="navbar-text me-3">
                    <i class="fas fa-user me-1"></i><?php echo $_SESSION['username']; ?>
                </span>
                
                <!-- Logout Link -->
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- Main Content Container -->
    <div class="container mt-4">
        <!-- Page Header with Add Course Button -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>
                <i class="fas fa-book-open me-2"></i>Course Management
            </h1>
            <a href="create.php" class="btn btn-success btn-lg">
                <i class="fas fa-plus"></i> Add New Course
            </a>
        </div>

        <!-- Display Session Messages (Success/Error) -->
        <?php if (isset($message)): ?>
            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show">
                <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-triangle'; ?> me-2"></i>
                <?php echo $message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Search & Filter Section -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-search"></i> Search & Filter Courses</h5>
            </div>
            <div class="card-body">
                <!-- Search and Filter Form -->
                <form method="GET" class="row g-3">
                    <!-- Search Input -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="fas fa-search me-1"></i>Search Courses
                        </label>
                        <div class="input-group">
                            <!-- Search input field with current search term preserved -->
                            <input type="text" name="search" class="form-control" placeholder="Search by course name, code, or description..." value="<?php echo htmlspecialchars($search_term); ?>">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> Search
                            </button>
                        </div>
                    </div>
                    
                    <!-- Status Filter Dropdown -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            <i class="fas fa-filter me-1"></i>Filter by Status
                        </label>
                        <select name="status" class="form-select" onchange="this.form.submit()">
                            <option value="all" <?php echo $filter_status === 'all' ? 'selected' : ''; ?>>All Courses</option>
                            <option value="active" <?php echo $filter_status === 'active' ? 'selected' : ''; ?>>Active Only</option>
                            <option value="inactive" <?php echo $filter_status === 'inactive' ? 'selected' : ''; ?>>Inactive Only</option>
                        </select>
                    </div>
                    
                    <!-- Reset Button -->
                    <div class="col-md-2">
                        <label class="form-label fw-semibold">&nbsp;</label>
                        <a href="list.php" class="btn btn-secondary w-100">
                            <i class="fas fa-refresh"></i> Reset
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Courses Table Section -->
        <?php if (empty($courses)): ?>
            <!-- No Courses Found Message -->
            <div class="alert alert-info text-center">
                <h4><i class="fas fa-info-circle me-2"></i> No Courses Found</h4>
                <p class="mb-3">
                    <?php if (!empty($search_term)): ?>
                        <!-- Message for empty search results -->
                        No courses found for your search criteria.
                    <?php elseif ($filter_status !== 'all'): ?>
                        <!-- Message for empty filtered results -->
                        No <?php echo $filter_status === 'active' ? 'active' : 'inactive'; ?> courses found.
                    <?php else: ?>
                        <!-- Message for completely empty course list -->
                        No courses available in the system.
                    <?php endif; ?>
                </p>
                <!-- Add First Course Button -->
                <a href="create.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i>Add First Course
                </a>
            </div>
        <?php else: ?>
            <!-- Courses Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Course Name</th>
                                    <th>Course Code</th>
                                    <th>Credits</th>
                                    <th>Fee</th>
                                    <th>Start Date</th>
                                    <th>Status</th>
                                    <th>Instructor</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Loop through each course and display in table row -->
                                <?php foreach ($courses as $course): ?>
                                <tr>
                                    <!-- Course ID -->
                                    <td><?php echo $course['CourseID']; ?></td>
                                    
                                    <!-- Course Name with Description -->
                                    <td>
                                        <strong><?php echo htmlspecialchars($course['CourseName']); ?></strong>
                                        <?php if ($course['Description']): ?>
                                            <br><small class="text-muted"><?php echo htmlspecialchars($course['Description']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <!-- Course Code -->
                                    <td>
                                        <code><?php echo htmlspecialchars($course['CourseCode']); ?></code>
                                    </td>
                                    
                                    <!-- Credits -->
                                    <td>
                                        <span class="badge bg-info"><?php echo $course['Credits']; ?> Credits</span>
                                    </td>
                                    
                                    <!-- Course Fee -->
                                    <td>
                                        <strong>$<?php echo number_format($course['Fee'], 2); ?></strong>
                                    </td>
                                    
                                    <!-- Start Date (formatted) -->
                                    <td>
                                        <?php echo date('M j, Y', strtotime($course['StartDate'])); ?>
                                    </td>
                                    
                                    <!-- Active/Inactive Status Badge -->
                                    <td>
                                        <?php if ($course['IsActive']): ?>
                                            <span class="badge bg-success status-badge">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary status-badge">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <!-- Instructor Name -->
                                    <td>
                                        <?php if ($course['FirstName']): ?>
                                            <?php echo htmlspecialchars($course['FirstName'] . ' ' . $course['LastName']); ?>
                                        <?php else: ?>
                                            <span class="text-muted">Not assigned</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <!-- Action Buttons -->
                                    <td>
                                        <!-- Action Buttons Container -->
                                        <div class="action-buttons">
                                            <!-- View Button (JavaScript function) -->
                                            <button type="button" 
                                                    class="btn btn-view"
                                                    onclick="viewCourseDetails(<?php echo $course['CourseID']; ?>)"
                                                    title="View Course Details">
                                                <i class="fas fa-eye"></i>
                                                <span class="text">View</span>
                                            </button>
                                            
                                            <!-- Edit Button (links to edit page) -->
                                            <a href="edit.php?id=<?php echo $course['CourseID']; ?>" 
                                               class="btn btn-edit" 
                                               title="Edit Course Details">
                                                <i class="fas fa-edit"></i>
                                                <span class="text">Edit</span>
                                            </a>
                                            
                                            <!-- Conditional: Activate or Deactivate Button -->
                                            <?php if ($course['IsActive']): ?>
                                                <!-- Deactivate Button for active courses -->
                                                <a href="deactivate.php?id=<?php echo $course['CourseID']; ?>" 
                                                   class="btn btn-deactivate"
                                                   onclick="return confirm('Deactivate this course?')"
                                                   title="Deactivate Course">
                                                    <i class="fas fa-pause"></i>
                                                    <span class="text">Deactivate</span>
                                                </a>
                                            <?php else: ?>
                                                <!-- Activate Button for inactive courses -->
                                                <a href="activate.php?id=<?php echo $course['CourseID']; ?>" 
                                                   class="btn btn-activate"
                                                   title="Activate Course">
                                                    <i class="fas fa-play"></i>
                                                    <span class="text">Activate</span>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <!-- Delete Button with confirmation -->
                                            <a href="delete.php?id=<?php echo $course['CourseID']; ?>" 
                                               class="btn btn-delete"
                                               onclick="return confirm('Are you sure you want to delete this course?')"
                                               title="Delete Course">
                                                <i class="fas fa-trash"></i>
                                                <span class="text">Delete</span>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- External JavaScript libraries -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript functions -->
    <script>
        /**
         * View Course Details Function
         * Displays course details (placeholder implementation)
         * @param {number} courseId - The ID of the course to view
         */
        function viewCourseDetails(courseId) {
            // This is a placeholder. In a real implementation, this would:
            // 1. Show a modal with detailed course information, or
            // 2. Redirect to a detailed view page
            alert('Viewing details for course ID: ' + courseId + '\n\nIn a complete implementation, this would show detailed course information in a modal or separate page.');
        }
    </script>
</body>
</html>